from flask import request, jsonify, Blueprint
from datetime import datetime

from database import celulas

queries_bp = Blueprint('routes-tasks', __name__)

@queries_bp.route('/queries', methods=['POST'])
def add_empleado():
    proyecto = request.json["proyecto"]
    empresa = request.json['empresa']
    persona = request.json['persona']
    areanegocio = request.json['areanegocio']
    cargo = request.json['cargo']
    competencias = request.json['competencias']
    

    data = (proyecto, empresa, persona, areanegocio, cargo, competencias)
    empleado_id = celulas.insert_empleado(data)


    if empleado_id:
        emp = celulas.select_empleado_by_id(empleado_id)
       
        return jsonify(emp)
    return jsonify({'message': 'Error interno'})


@queries_bp.route('/queries', methods=['GET'])
def get_empleado():
    data = celulas.select_all_empleado()

    if data:
        return jsonify({'celulas': data})
    elif data == False:
        return jsonify({'message': 'Error interno'})
    else:
        return jsonify({'celulas': {}})

@queries_bp.route('/queries', methods=['PUT'])
def update_empleado():
    proyecto = request.json['proyecto']
    id_arg = request.args.get('id')

    if celulas.update_empleado(id_arg, (proyecto,)):

        task = celulas.select_empleado_by_id(id_arg)
        return jsonify(task)
    return jsonify({'message': 'Error interno'})

@queries_bp.route('/queries', methods=['DELETE'])
def delete_empleado():
    id_arg = request.args.get('id')

    if celulas.delete_empleado(id_arg):
        return jsonify({'message': 'Celula eliminada'})
    return jsonify({'message': 'Error interno'})


@queries_bp.route('/queries/estatus', methods=['PUT'])
def estatus_empleado():
    id_arg = request.args.get('id')
    completed = request.args.get('estatus')

    if celulas.estatus_empleado(id_arg, estatus):
        return jsonify({'message': 'Cambio de estatus exitoso'})
    return jsonify({'message': 'Error interno'})