from flask import Flask
	
from database import setup


from resources.queries import queries_bp
	
app = Flask(__name__)
setup.create_tables()

app.register_blueprint(queries_bp)
	
	
	
if __name__ == '__main__':
	app.run(debug=True)
