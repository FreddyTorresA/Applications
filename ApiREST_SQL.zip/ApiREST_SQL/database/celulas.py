import sqlite3
from sqlite3 import Error
	
from .connection import create_connection
	
	
def insert_empleado(data):
	    conn = create_connection()
	
	    sql = """ INSERT INTO celulas (proyecto, empresa, persona, areanegocio, cargo, competencias)
	             VALUES(?, ?, ?, ?, ?, ?)
	    """
	
	    try:
	        cur = conn.cursor()
	        cur.execute(sql, data)
	        conn.commit()
	        return cur.lastrowid
	    except Error as e:
	        print(f"Error en insert_empleado() : {str(e)}")
	        return False
	    
	    finally:
	        if conn:
	            cur.close()
	            conn.close()
	
def select_empleado_by_id(_id):
	    conn = create_connection()
	    
	    sql = f"SELECT * FROM celulas WHERE id = {_id}" 
	
	    try:
	        conn.row_factory = sqlite3.Row
	        cur = conn.cursor()
	        cur.execute(sql)
	        task = dict(cur.fetchone())
	        return task
	    except Error as e:
	        print(f"Error en select_empleado_by_id : {str(e)}")
	        return False
	    finally:
	        if conn:
	            cur.close()
	            conn.close()
	
	
def select_all_empleado():
	    conn = create_connection()
	
	    sql = "SELECT * FROM celulas"
	    try:
	        conn.row_factory = sqlite3.Row
	        cur = conn.cursor()
	        cur.execute(sql)
	        task_rows = cur.fetchall()
	        tasks = [ dict(row) for row in task_rows ]
	        return tasks
	    except Error as e:
	        print(f"Error en select_all_empleado() : {str(e)}")
	        return False
	    finally:
	        if conn:
	            cur.close()
	            conn.close()
	
	
def update_empleado(_id, data):
	    conn = create_connection()
	
	    sql = f""" UPDATE celulas SET proyecto = ?
	             WHERE id = {_id}
	    """
	
	    try:
	        cur = conn.cursor()
	        cur.execute(sql, data)
	        conn.commit()
	        return True
	    except Error as e:
	        print(f"Error en update_empleado() : {str(e)}")
	        return False
	    
	    finally:
	        if conn:
	            cur.close()
	            conn.close()
	
def delete_empleado(_id):
	    conn = create_connection()
	
	    sql = f"DELETE FROM celulas WHERE id = {_id}"
	
	    try:
	        cur = conn.cursor()
	        cur.execute(sql)
	        conn.commit()
	        return True
	    except Error as e:
	        print(f"Error en delete_empleado() {str(e)}")
	    
	    finally:
	        if conn:
	            cur.close()
	            conn.close()
	
	
def estatus_empleado(_id, estatus):
	    conn = create_connection()
	
	    sql = f""" UPDATE celulas SET estatus = {estatus}
	            WHERE id = {_id}
	    """
	    try:
	        cur = conn.cursor()
	        cur.execute(sql)
	        conn.commit()
	        return True
	    except Error as e:
	        print(f"Error en estatus_empleado : {str(e)}")
	    finally:
	        if conn:
	            cur.close()
	            conn.close()
