CREATE TABLE IF NOT EXISTS celulas(
	    id INTEGER PRIMARY KEY,
		proyecto TEXT NOT NULL,
		empresa TEXT NOT NULL,
	    persona TEXT NOT NULL,
		areanegocio TEXT NOT NULL,
		cargo TEXT NOT NULL,
		competencias TEXT NOT NUll,
	    estatus INTEGER NOT NULL DEFAULT 0
	)
